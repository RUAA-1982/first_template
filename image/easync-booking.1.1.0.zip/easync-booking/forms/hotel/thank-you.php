<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="modal fade" id="hotel_thank_you_modal" tabindex="-1" role="dialog" aria-labelledby="thank-youLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
	<div class="modal-body">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
      <center><h2>Thank you !</h2></center>
      <center><h3>Thank you</h3></center>
	</div>
</div>
</div>
</div>